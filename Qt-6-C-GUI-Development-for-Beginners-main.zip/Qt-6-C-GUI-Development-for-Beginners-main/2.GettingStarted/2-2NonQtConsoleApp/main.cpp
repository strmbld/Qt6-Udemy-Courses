#include <iostream>

int main()
{
    std::cout << "Hello World. How are you doing!" << std::endl;
    return 0;
}
