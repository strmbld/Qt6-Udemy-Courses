#include <iostream>

//Declaration
double add (double a, double b);

int main()
{
   auto result = add(10,20);
   std::cout << "result : " << result << std::endl;
    return 0;
}



